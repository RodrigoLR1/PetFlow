const Database = require('better-sqlite3');
const path = require('path');

const DB_PATH = path.join(__dirname, 'petpanel.db');
const db = new Database(DB_PATH);

// ─── Habilita WAL mode para melhor performance ───
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ─── Criação das tabelas ───────────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS clients (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT    NOT NULL,
    phone      TEXT    NOT NULL DEFAULT '',
    email      TEXT    NOT NULL DEFAULT '',
    color      TEXT    NOT NULL DEFAULT '#f97316',
    joined     TEXT    NOT NULL DEFAULT '',
    created_at DATETIME NOT NULL DEFAULT (datetime('now','localtime'))
  );

  CREATE TABLE IF NOT EXISTS pets (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT    NOT NULL,
    breed      TEXT    NOT NULL DEFAULT '',
    tutor      TEXT    NOT NULL DEFAULT '',
    client_id  INTEGER,
    phone      TEXT    NOT NULL DEFAULT '',
    service    TEXT    NOT NULL DEFAULT 'Banho Completo',
    status     TEXT    NOT NULL DEFAULT 'checkin',
    avatar     TEXT    NOT NULL DEFAULT '🐕',
    color      TEXT    NOT NULL DEFAULT '#f97316',
    created_at DATETIME NOT NULL DEFAULT (datetime('now','localtime')),
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL
  );
`);

// ─── Seed: inserir dados iniciais se as tabelas estiverem vazias ──
const clientCount = db.prepare('SELECT COUNT(*) as cnt FROM clients').get();
if (clientCount.cnt === 0) {
  const insertClient = db.prepare(`
    INSERT INTO clients (name, phone, email, color, joined)
    VALUES (@name, @phone, @email, @color, @joined)
  `);

  const seedClients = [
    { name: 'Maria Silva',   phone: '(83) 99999-0001', email: 'maria@email.com',   color: '#f97316', joined: 'Jan 2025' },
    { name: 'Carlos Santos', phone: '(83) 99999-0002', email: 'carlos@email.com',  color: '#a78bfa', joined: 'Fev 2025' },
    { name: 'Ana Oliveira',  phone: '(83) 99999-0003', email: 'ana@email.com',     color: '#38bdf8', joined: 'Mar 2025' },
    { name: 'João Pedro',    phone: '(83) 99999-0004', email: 'joao@email.com',    color: '#f43f5e', joined: 'Mar 2025' },
    { name: 'Paula Costa',   phone: '(83) 99999-0005', email: 'paula@email.com',   color: '#10b981', joined: 'Abr 2025' },
    { name: 'Roberto Alves', phone: '(83) 99999-0006', email: 'roberto@email.com', color: '#6366f1', joined: 'Abr 2025' },
  ];

  const insertManyClients = db.transaction((clients) => {
    for (const c of clients) insertClient.run(c);
  });
  insertManyClients(seedClients);
}

const petCount = db.prepare('SELECT COUNT(*) as cnt FROM pets').get();
if (petCount.cnt === 0) {
  const insertPet = db.prepare(`
    INSERT INTO pets (name, breed, tutor, client_id, phone, service, status, avatar, color)
    VALUES (@name, @breed, @tutor, @client_id, @phone, @service, @status, @avatar, @color)
  `);

  // Busca IDs dos clientes recem-inseridos
  const clients = db.prepare('SELECT id, name FROM clients').all();
  const cMap = {};
  clients.forEach(c => { cMap[c.name] = c.id; });

  const seedPets = [
    { name: 'Rex',  breed: 'Golden Retriever', tutor: 'Maria Silva',   client_id: cMap['Maria Silva'],   phone: '(83) 99999-0001', service: 'Banho + Tosa',       status: 'checkin', avatar: '🐕', color: '#f97316' },
    { name: 'Luna', breed: 'Shih Tzu',         tutor: 'Carlos Santos', client_id: cMap['Carlos Santos'], phone: '(83) 99999-0002', service: 'Banho Completo',     status: 'checkin', avatar: '🐩', color: '#a78bfa' },
    { name: 'Thor', breed: 'Husky Siberiano',  tutor: 'Ana Oliveira',  client_id: cMap['Ana Oliveira'],  phone: '(83) 99999-0003', service: 'Tosa Higiênica',     status: 'checkin', avatar: '🦮', color: '#38bdf8' },
    { name: 'Mel',  breed: 'Poodle',           tutor: 'João Pedro',    client_id: cMap['João Pedro'],    phone: '(83) 99999-0004', service: 'Banho + Hidratação', status: 'banho',   avatar: '🐶', color: '#f43f5e' },
    { name: 'Bob',  breed: 'Bulldog Francês',  tutor: 'João Pedro',    client_id: cMap['João Pedro'],    phone: '(83) 99999-0004', service: 'Banho Simples',      status: 'banho',   avatar: '🐕', color: '#fbbf24' },
    { name: 'Nina', breed: 'Yorkshire',        tutor: 'Paula Costa',   client_id: cMap['Paula Costa'],   phone: '(83) 99999-0005', service: 'Banho + Tosa Bebê',  status: 'pronto',  avatar: '🐾', color: '#10b981' },
    { name: 'Max',  breed: 'Labrador',         tutor: 'Roberto Alves', client_id: cMap['Roberto Alves'], phone: '(83) 99999-0006', service: 'Banho Completo',     status: 'pronto',  avatar: '🐕', color: '#6366f1' },
  ];

  const insertManyPets = db.transaction((pets) => {
    for (const p of pets) insertPet.run(p);
  });
  insertManyPets(seedPets);
}

console.log(`✅ Banco de dados inicializado em: ${DB_PATH}`);

module.exports = db;
