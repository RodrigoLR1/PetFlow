const express = require('express');
const router = express.Router();
const db = require('../database');

// ─── GET /api/clients ──────────────────────────────
// Retorna todos os clientes com a lista de pets
router.get('/', (req, res) => {
  try {
    const clients = db.prepare(`
      SELECT * FROM clients
      ORDER BY created_at DESC
    `).all();

    // Para cada cliente, busca os nomes dos pets associados
    const result = clients.map(client => {
      const pets = db.prepare(`
        SELECT name FROM pets WHERE client_id = ?
      `).all(client.id);
      return {
        ...client,
        pets: pets.map(p => p.name),
      };
    });

    res.json(result);
  } catch (err) {
    console.error('Erro ao buscar clientes:', err);
    res.status(500).json({ error: 'Erro interno ao buscar clientes.' });
  }
});

// ─── POST /api/clients ─────────────────────────────
// Cria um novo cliente (tutor)
router.post('/', (req, res) => {
  const { name, phone, email, color, petName } = req.body;

  if (!name) {
    return res.status(400).json({ error: 'Nome do cliente é obrigatório.' });
  }

  try {
    const now = new Date();
    const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    const joined = `${months[now.getMonth()]} ${now.getFullYear()}`;

    const stmt = db.prepare(`
      INSERT INTO clients (name, phone, email, color, joined)
      VALUES (@name, @phone, @email, @color, @joined)
    `);

    const result = stmt.run({
      name:   name.trim(),
      phone:  phone  || '',
      email:  email  || '',
      color:  color  || '#f97316',
      joined: joined,
    });

    const newClient = db.prepare('SELECT * FROM clients WHERE id = ?').get(result.lastInsertRowid);

    // Retorna com array de pets (vazio inicialmente ou com petName)
    res.status(201).json({
      ...newClient,
      pets: petName ? [petName] : [],
    });
  } catch (err) {
    console.error('Erro ao criar cliente:', err);
    res.status(500).json({ error: 'Erro interno ao criar cliente.' });
  }
});

// ─── PUT /api/clients/:id ──────────────────────────
// Atualiza dados de um cliente
router.put('/:id', (req, res) => {
  const { id } = req.params;
  const { name, phone, email, color } = req.body;

  if (!name) {
    return res.status(400).json({ error: 'Nome é obrigatório.' });
  }

  try {
    const client = db.prepare('SELECT * FROM clients WHERE id = ?').get(id);
    if (!client) {
      return res.status(404).json({ error: 'Cliente não encontrado.' });
    }

    db.prepare(`
      UPDATE clients SET name = ?, phone = ?, email = ?, color = ?
      WHERE id = ?
    `).run(name.trim(), phone || '', email || '', color || '#f97316', id);

    const updated = db.prepare('SELECT * FROM clients WHERE id = ?').get(id);
    const pets = db.prepare('SELECT name FROM pets WHERE client_id = ?').all(id);

    res.json({ ...updated, pets: pets.map(p => p.name) });
  } catch (err) {
    console.error('Erro ao atualizar cliente:', err);
    res.status(500).json({ error: 'Erro interno ao atualizar cliente.' });
  }
});

// ─── DELETE /api/clients/:id ───────────────────────
// Remove um cliente
router.delete('/:id', (req, res) => {
  const { id } = req.params;

  try {
    const client = db.prepare('SELECT * FROM clients WHERE id = ?').get(id);
    if (!client) {
      return res.status(404).json({ error: 'Cliente não encontrado.' });
    }

    db.prepare('DELETE FROM clients WHERE id = ?').run(id);
    res.json({ success: true, message: `Cliente "${client.name}" removido com sucesso.` });
  } catch (err) {
    console.error('Erro ao remover cliente:', err);
    res.status(500).json({ error: 'Erro interno ao remover cliente.' });
  }
});

module.exports = router;
