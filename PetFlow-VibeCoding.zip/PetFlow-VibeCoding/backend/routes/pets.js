const express = require('express');
const router = express.Router();
const db = require('../database');

// ─── GET /api/pets ─────────────────────────────────
// Retorna todos os pets (do dia atual por padrão)
router.get('/', (req, res) => {
  try {
    const pets = db.prepare(`
      SELECT * FROM pets
      ORDER BY created_at DESC
    `).all();
    res.json(pets);
  } catch (err) {
    console.error('Erro ao buscar pets:', err);
    res.status(500).json({ error: 'Erro interno ao buscar pets.' });
  }
});

// ─── POST /api/pets ────────────────────────────────
// Cria um novo check-in de pet
router.post('/', (req, res) => {
  const { name, breed, tutor, client_id, phone, service, avatar, color } = req.body;

  if (!name || !tutor) {
    return res.status(400).json({ error: 'Nome do pet e tutor são obrigatórios.' });
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO pets (name, breed, tutor, client_id, phone, service, status, avatar, color)
      VALUES (@name, @breed, @tutor, @client_id, @phone, @service, 'checkin', @avatar, @color)
    `);

    const result = stmt.run({
      name:      name.trim(),
      breed:     breed    || '',
      tutor:     tutor.trim(),
      client_id: client_id || null,
      phone:     phone    || '',
      service:   service  || 'Banho Completo',
      avatar:    avatar   || '🐕',
      color:     color    || '#f97316',
    });

    const newPet = db.prepare('SELECT * FROM pets WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(newPet);
  } catch (err) {
    console.error('Erro ao criar pet:', err);
    res.status(500).json({ error: 'Erro interno ao criar pet.' });
  }
});

// ─── PATCH /api/pets/:id/status ────────────────────
// Atualiza o status de um pet (checkin → banho → pronto)
router.patch('/:id/status', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  const validStatuses = ['checkin', 'banho', 'pronto'];
  if (!status || !validStatuses.includes(status)) {
    return res.status(400).json({ error: `Status inválido. Use: ${validStatuses.join(', ')}` });
  }

  try {
    const pet = db.prepare('SELECT * FROM pets WHERE id = ?').get(id);
    if (!pet) {
      return res.status(404).json({ error: 'Pet não encontrado.' });
    }

    db.prepare('UPDATE pets SET status = ? WHERE id = ?').run(status, id);
    const updated = db.prepare('SELECT * FROM pets WHERE id = ?').get(id);
    res.json(updated);
  } catch (err) {
    console.error('Erro ao atualizar status:', err);
    res.status(500).json({ error: 'Erro interno ao atualizar status.' });
  }
});

// ─── DELETE /api/pets/:id ──────────────────────────
// Remove um pet do painel
router.delete('/:id', (req, res) => {
  const { id } = req.params;

  try {
    const pet = db.prepare('SELECT * FROM pets WHERE id = ?').get(id);
    if (!pet) {
      return res.status(404).json({ error: 'Pet não encontrado.' });
    }

    db.prepare('DELETE FROM pets WHERE id = ?').run(id);
    res.json({ success: true, message: `Pet "${pet.name}" removido com sucesso.` });
  } catch (err) {
    console.error('Erro ao remover pet:', err);
    res.status(500).json({ error: 'Erro interno ao remover pet.' });
  }
});

module.exports = router;
