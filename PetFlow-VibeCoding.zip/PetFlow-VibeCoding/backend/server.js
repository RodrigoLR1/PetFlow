const express = require('express');
const cors    = require('cors');
const path    = require('path');

// Inicializa o banco de dados (cria tabelas + seed se necessário)
require('./database');

const petsRouter    = require('./routes/pets');
const clientsRouter = require('./routes/clients');

const app  = express();
const PORT = 3001;

// ─── Middlewares ─────────────────────────────────────────────
app.use(cors());                          // Permite chamadas do front-end
app.use(express.json());                  // Parse JSON no body
app.use(express.urlencoded({ extended: true }));

// ─── Servir arquivos estáticos do projeto ────────────────────
// O servidor também serve os HTMLs da raiz do projeto
app.use(express.static(path.join(__dirname, '..')));

// ─── Rotas da API ────────────────────────────────────────────
app.use('/api/pets',    petsRouter);
app.use('/api/clients', clientsRouter);

// ─── Health check ────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    message: 'PetPanel API está funcionando! 🐾',
    timestamp: new Date().toISOString(),
  });
});

// ─── Rota raiz → redireciona para o app ──────────────────────
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'PetPanelApp.html'));
});

app.get('/landing', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'PetPanel - Landing Page.html'));
});

// ─── Rota 404 genérica ────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: `Rota não encontrada: ${req.method} ${req.path}` });
});

// ─── Inicia o servidor ────────────────────────────────────────
app.listen(PORT, () => {
  console.log('');
  console.log('╔══════════════════════════════════════════╗');
  console.log('║   🐾  PetPanel API — Servidor iniciado   ║');
  console.log(`║   http://localhost:${PORT}                   ║`);
  console.log('║                                          ║');
  console.log(`║   App:     http://localhost:${PORT}/          ║`);
  console.log(`║   Landing: http://localhost:${PORT}/landing   ║`);
  console.log(`║   API:     http://localhost:${PORT}/api/      ║`);
  console.log('╚══════════════════════════════════════════╝');
  console.log('');
});
